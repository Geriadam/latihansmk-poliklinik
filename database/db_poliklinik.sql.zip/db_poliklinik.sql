-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 31, 2017 at 02:17 PM
-- Server version: 5.1.37
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_poliklinik`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id_admin` int(12) NOT NULL AUTO_INCREMENT,
  `user` varchar(50) NOT NULL,
  `pass` varchar(32) NOT NULL,
  `tipe` varchar(30) NOT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `user`, `pass`, `tipe`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `dokter`
--

CREATE TABLE IF NOT EXISTS `dokter` (
  `id_dokter` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `alamat` text NOT NULL,
  `tanggal` date NOT NULL,
  `telp` varchar(12) NOT NULL,
  `gambar` varchar(200) NOT NULL,
  `poliklinik` varchar(20) NOT NULL,
  PRIMARY KEY (`id_dokter`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `dokter`
--

INSERT INTO `dokter` (`id_dokter`, `nama`, `alamat`, `tanggal`, `telp`, `gambar`, `poliklinik`) VALUES
(20, 'Geri Adam Saputra', 'Jombang', '2009-02-12', '093049808209', '1009.png', '1'),
(21, 'Ivan Setyawan', 'Mojokerto', '2009-03-05', '908028490849', '1009.png', '5'),
(22, 'Fikri Bachtiar', 'Mojokerto', '1990-07-11', '090842808490', '1001.png', '3'),
(23, 'Igga Afidya', 'Jombang', '1990-06-20', '081239810380', '1003.png', '2'),
(24, 'Mohammad Faisal', 'Jombang', '1994-06-10', '091289301390', '1011.png', '4'),
(25, 'Muhammad Aman', 'Jombang', '2000-06-21', '081293819310', '1005.png', '3');

-- --------------------------------------------------------

--
-- Table structure for table `obat`
--

CREATE TABLE IF NOT EXISTS `obat` (
  `id_obat` int(20) NOT NULL AUTO_INCREMENT,
  `nama_obat` varchar(50) NOT NULL,
  `jenis` varchar(20) NOT NULL,
  `harga` int(10) NOT NULL,
  `stok` int(5) NOT NULL,
  PRIMARY KEY (`id_obat`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `obat`
--

INSERT INTO `obat` (`id_obat`, `nama_obat`, `jenis`, `harga`, `stok`) VALUES
(8, 'Mixagrip', 'Pil', 2000, 39),
(9, 'Panadol', 'Pil', 1000, 57),
(10, 'Bodrex', 'Pil', 1000, 9),
(11, 'Paramex', 'Pil', 3000, 55),
(12, 'Vidoran', 'Sirup', 10000, 37),
(13, 'Mixagrip Flu', 'Pil', 2000, 72);

-- --------------------------------------------------------

--
-- Table structure for table `pasien`
--

CREATE TABLE IF NOT EXISTS `pasien` (
  `id_pasien` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `alamat` text NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `telp` varchar(12) NOT NULL,
  `jenis_kelamin` varchar(15) NOT NULL,
  `tanggal` date NOT NULL,
  `poliklinik` varchar(5) NOT NULL,
  PRIMARY KEY (`id_pasien`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `pasien`
--

INSERT INTO `pasien` (`id_pasien`, `nama`, `alamat`, `tanggal_lahir`, `telp`, `jenis_kelamin`, `tanggal`, `poliklinik`) VALUES
(17, 'Geri', 'jombang', '2009-02-03', '081555999989', 'Laki-Laki', '2017-01-26', '2'),
(18, 'Yusuf Pradana', 'Jombang', '1990-02-15', '082193891839', 'Laki-Laki', '2017-01-30', '4');

-- --------------------------------------------------------

--
-- Table structure for table `pegawai`
--

CREATE TABLE IF NOT EXISTS `pegawai` (
  `id_pegawai` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `alamat` text NOT NULL,
  `telp` varchar(12) NOT NULL,
  `tanggal` date NOT NULL,
  `jk` varchar(15) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL,
  `tipe` varchar(20) NOT NULL,
  PRIMARY KEY (`id_pegawai`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `pegawai`
--

INSERT INTO `pegawai` (`id_pegawai`, `nama`, `alamat`, `telp`, `tanggal`, `jk`, `username`, `password`, `tipe`) VALUES
(1, 'Reza Tumihiho', 'Jombang', '082248498294', '2000-06-29', 'Laki-Laki', 'admin2', 'c84258e9c39059a89ab77d846ddab909', 'Pegawai'),
(3, 'Geri Adam Saputra', 'Jombang', '093028408018', '2000-06-20', 'Laki-Laki', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Pegawai'),
(4, 'Munir Hamsah', 'Jombang', '083813091031', '1994-02-16', 'Laki-Laki', 'admin1', 'e00cf25ad42683b3df678c61f42c6bda', 'Pegawai'),
(5, 'Alif Nur Hidayat', 'Jombang', '084828392839', '2000-06-15', 'Laki-Laki', 'admin3', '32cacb2f994f6b42183a1300d9a3e8d6', 'Pegawai');

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE IF NOT EXISTS `pembayaran` (
  `id_pembayaran` int(15) NOT NULL AUTO_INCREMENT,
  `id_tindakan` varchar(15) NOT NULL,
  `total` int(15) NOT NULL,
  `bayar` int(15) NOT NULL,
  `kembalian` int(15) NOT NULL,
  `jam` time NOT NULL,
  `tanggal` date NOT NULL,
  `status` varchar(30) NOT NULL,
  PRIMARY KEY (`id_pembayaran`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=113 ;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`id_pembayaran`, `id_tindakan`, `total`, `bayar`, `kembalian`, `jam`, `tanggal`, `status`) VALUES
(111, '20170131093830', 16000, 20000, 4000, '14:14:42', '2017-01-31', 'Sudah Bayar'),
(112, '20170131102350', 46000, 0, 0, '10:24:09', '2017-01-31', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `pemeriksaan`
--

CREATE TABLE IF NOT EXISTS `pemeriksaan` (
  `id_pemeriksaan` varchar(30) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `id_pasien` varchar(15) NOT NULL,
  `id_poli` varchar(15) NOT NULL,
  `id_penyakit` varchar(15) NOT NULL,
  `id_dokter` varchar(15) NOT NULL,
  `id_obat` varchar(15) NOT NULL,
  `jumlah` int(5) NOT NULL,
  `harga` int(12) NOT NULL,
  `total` int(12) NOT NULL,
  `catatan` text NOT NULL,
  PRIMARY KEY (`id_pemeriksaan`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemeriksaan`
--

INSERT INTO `pemeriksaan` (`id_pemeriksaan`, `tanggal`, `jam`, `id_pasien`, `id_poli`, `id_penyakit`, `id_dokter`, `id_obat`, `jumlah`, `harga`, `total`, `catatan`) VALUES
('20170131102350', '2017-01-31', '10:24:09', '18', '4', '38', '24', '10 8 13 11 12  ', 2, 18000, 46000, 'Sering Istirahat'),
('20170131093830', '2017-01-31', '09:39:11', '17', '2', '36', '23', '10 13         ', 2, 3000, 16000, 'Sering Itirahat');

-- --------------------------------------------------------

--
-- Table structure for table `penyakit`
--

CREATE TABLE IF NOT EXISTS `penyakit` (
  `id_penyakit` int(10) NOT NULL AUTO_INCREMENT,
  `id_poli` int(10) NOT NULL,
  `nama_penyakit` varchar(50) NOT NULL,
  PRIMARY KEY (`id_penyakit`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=40 ;

--
-- Dumping data for table `penyakit`
--

INSERT INTO `penyakit` (`id_penyakit`, `id_poli`, `nama_penyakit`) VALUES
(30, 1, 'Gigi Bolong'),
(31, 1, 'Gusi Bengkak'),
(32, 5, 'Mimisan'),
(33, 5, 'Pilek'),
(34, 3, 'Panu'),
(35, 3, 'Kurap'),
(36, 2, 'Rabun Jauh'),
(37, 2, 'Rabun Dekat'),
(38, 4, 'Kopok'),
(39, 4, 'Tuli');

-- --------------------------------------------------------

--
-- Table structure for table `poliklinik`
--

CREATE TABLE IF NOT EXISTS `poliklinik` (
  `id_poli` int(10) NOT NULL AUTO_INCREMENT,
  `nama_poli` varchar(20) NOT NULL,
  PRIMARY KEY (`id_poli`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `poliklinik`
--

INSERT INTO `poliklinik` (`id_poli`, `nama_poli`) VALUES
(4, 'Poliklinik THT'),
(3, 'Poliklinik Kulit'),
(2, 'Poliklinik Mata'),
(1, 'Poliklinik Gigi'),
(5, 'Poliklinik Hidung');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
